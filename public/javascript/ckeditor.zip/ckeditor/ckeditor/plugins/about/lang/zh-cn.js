﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'about', 'zh-cn', {
	copy: '版权所有 &copy; $1。<br />保留所有权利。',
	dlgTitle: '关于 CKEditor 4',
	moreInfo: '相关授权许可信息请访问我们的网站：'
} );
