﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'about', 'ro', {
	copy: 'Copyright &copy; $1. Toate drepturile rezervate.',
	dlgTitle: 'Despre CKEeditor 4',
	moreInfo: 'Pentru informații despre licențiere, vă rugăm vizitați web site-ul nostru:'
} );
