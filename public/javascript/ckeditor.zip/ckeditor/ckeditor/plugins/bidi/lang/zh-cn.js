﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'bidi', 'zh-cn', {
	ltr: '文字方向为从左至右',
	rtl: '文字方向为从右至左'
} );
