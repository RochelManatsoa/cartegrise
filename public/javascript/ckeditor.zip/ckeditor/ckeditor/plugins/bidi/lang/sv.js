﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'bidi', 'sv', {
	ltr: 'Text riktning från vänster till höger',
	rtl: 'Text riktning från höger till vänster'
} );
